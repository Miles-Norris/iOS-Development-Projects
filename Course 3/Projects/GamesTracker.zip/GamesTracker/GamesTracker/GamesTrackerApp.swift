//
//  GamesTrackerApp.swift
//  GamesTracker
//
//  Created by Miles Norris on 5/6/26.
//

import SwiftUI
import SwiftData

@main
struct GamesTrackerApp: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            GamesView(presenter: GamesPresenter(interactor: GameInteractor(), router: AppRouter.current))
        }
        .modelContainer(sharedModelContainer)
    }
}
