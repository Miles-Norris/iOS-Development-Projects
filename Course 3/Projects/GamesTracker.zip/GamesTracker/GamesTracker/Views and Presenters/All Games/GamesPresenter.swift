//
//  GamesPresenter.swift
//  GamesTracker
//
//  Created by Miles Norris on 5/6/26.
//

import Foundation
import SwiftUI
import SwiftData

@Observable
class GamesPresenter: Presenter {
    var interactor: GameInteractor
    var router: AppRouter
    
    var games: [Game] = [Game.dummyGame, Game.dummyGame2]
    
    init(interactor: GameInteractor, router: AppRouter) {
        self.interactor = interactor
        self.router = router
    }
    
    func newGameButtonPressed() {
        router.navigate(to: .newGame())
    }
    
    func gamePressed(game: Game) {
        router.navigate(to: .gameDetails(game: game))
    }
    
    func loadGames() {
        games = interactor.loadGames()
        if games.isEmpty {
            games = [Game.dummyGame, Game.dummyGame2]
        }
    }
    
    func createView(route: AppRouter.AppRoute) -> some View {
        router.view(for: route)
    }
    
}
