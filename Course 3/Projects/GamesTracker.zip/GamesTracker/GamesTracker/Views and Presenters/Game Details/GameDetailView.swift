//
//  GameDetailView.swift
//  GamesTracker
//
//  Created by Miles Norris on 5/6/26.
//

import SwiftUI

struct GameDetailView: View {
    @State var presenter: GameDetailPresenter
    
    var body: some View {
        List($presenter.game.players, editActions: .delete) { $player in
            HStack {
                PlayerSubview(player: player)
                
                Spacer()
                
                VStack {
                    Text("Score: \(player.score)")
                        .font(.system(size: player.isAnimated ? 23 : 22))
                        .bold()
                    
                    Stepper("", value: $player.score, in: 0...999)
                        .labelsHidden()
                        .frame(width: 10, height: 25)
                }
                .padding(.horizontal, 30)
            }
            .onChange(of: player.score) {
                withAnimation(.easeInOut(duration: 0.05)) {
                   player.isAnimated = true
                } completion: {
                    withAnimation(.easeInOut(duration: 0.05)) {
                        player.isAnimated = false
                    }
                }
                presenter.sortPlayers()
            }
        }
        .toolbar {
            ToolbarItem {
                EditButton()
            }
            ToolbarItem {
                Button {
                    presenter.settingsButtonPressed()
                } label: {
                    Label("Settings", systemImage: "gear")
                }
            }
        }
        .navigationTitle(presenter.game.name)
        .onChange(of: presenter.game.players) {
            presenter.sortPlayers()
        }
    }
}

#Preview {
    GameDetailView(presenter: GameDetailPresenter(interactor: GameInteractor(), router: AppRouter.current, game: Game.dummyGame))
}
