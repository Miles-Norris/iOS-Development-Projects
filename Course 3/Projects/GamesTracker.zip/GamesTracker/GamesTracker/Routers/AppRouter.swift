//
//  AppRouter.swift
//  GamesTracker
//
//  Created by Miles Norris on 5/6/26.
//

import Foundation
import SwiftUI

@Observable
class AppRouter {
    static let current = AppRouter()
    
    var navigationPath = NavigationPath()
    var gameInteractor = GameInteractor()
    
    enum AppRoute: Hashable {
        case allGames
        case newGame(game: Game? = nil)
        case gameDetails(game: Game)
        case newPlayer(game: Game)
    }
    
    @ViewBuilder
    func view(for route: AppRoute) -> some View {
        switch route {
        case .allGames:
            GamesView(presenter: GamesPresenter(interactor: gameInteractor, router: AppRouter.current))
        case .newGame(let game):
            AddEditGameView(presenter: AddEditGamePresenter(interactor: gameInteractor, router: AppRouter.current, game: game))
        case .gameDetails(let game):
            GameDetailView(presenter: GameDetailPresenter(interactor: gameInteractor, router: AppRouter.current, game: game))
        case .newPlayer(let game):
            NewPlayerView(presenter: NewPlayerPresenter(interactor: PlayerInteractor(), router: AppRouter.current, game: game))
        }
    }
    
    func navigate(to route: AppRoute) {
        navigationPath.append(route)
    }
    
    func popToRoot() {
        navigationPath = NavigationPath()
    }
}
